package com.example.martheapp;

import android.app.Activity;
import android.content.Intent;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;


public class MainActivity extends Activity {
	public MediaPlayer Mart;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button stt=(Button)findViewById(R.id.btnstart);
        Button stop=(Button)findViewById(R.id.btnstop);
        Button toastmess=(Button)findViewById(R.id.btntoas);
        Button exit=(Button)findViewById(R.id.btnexit);
        Button next=(Button)findViewById(R.id.btnnext);
        next.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				Intent Mart=new Intent(getApplicationContext(),MainActivity2.class);
				startActivity(Mart);
				
			}
		});
        
        
        exit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
			finish();
			System.exit(0);
				
			}
		});
        
        stt.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onCreate();
				Toast.makeText(MainActivity.this, "Iratangiye muryoherwe!", Toast.LENGTH_LONG).show();
				
			}
		});
        
        toastmess.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Toast.makeText(MainActivity.this, "This is Toast Message thx!", Toast.LENGTH_LONG).show();
				
			}
		});
        stop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				onDestroy();
			}
		});
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    
    public void onCreate(){
    	Toast.makeText(this, "service started", Toast.LENGTH_SHORT).show();
    	Mart=MediaPlayer.create(this, R.raw.music);
    	Mart.setLooping(false);
    	Mart.start();

    }
    public void onDestroy(){
    	Toast.makeText(this, "Service Stoped", Toast.LENGTH_LONG).show();
    	Mart.pause();
    	
        }
    
}
