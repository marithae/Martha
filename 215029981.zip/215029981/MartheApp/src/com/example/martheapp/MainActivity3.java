package com.example.martheapp;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.content.DialogInterface.OnClickListener;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.v4.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;

public class MainActivity3 extends DialogFragment {
	LayoutInflater inf;
	View v;
	
	@Override
	@NonNull
	public Dialog onCreateDialog(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		inf =getActivity().getLayoutInflater();
		v=inf.inflate(R.layout.layout3, null);
		AlertDialog.Builder cus=new AlertDialog.Builder(getActivity());
		cus.setView(v).setPositiveButton("OK", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		}).setNegativeButton("Cancer", new OnClickListener() {
			
			@Override
			public void onClick(DialogInterface arg0, int arg1) {
				// TODO Auto-generated method stub
				
			}
		});
		return cus.create();
		
	}

}
